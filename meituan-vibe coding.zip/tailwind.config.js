/** @type {import('tailwindcss').Config} */

export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    container: {
      center: true,
    },
    extend: {
      colors: {
        // 办公级高对比度背景
        'bg-base': '#F0F2F5',
        'bg-surface': '#FFFFFF',
        'bg-elevated': '#FFFFFF',
        'bg-hover': '#E8EBF0',
        'bg-active': '#DEE2E8',
        'bg-glass': 'rgba(255, 255, 255, 0.90)',
        'bg-glass-hover': 'rgba(255, 255, 255, 0.98)',
        
        // 办公级高对比度文字
        'text-primary': '#1A1D23',
        'text-secondary': '#4A5568',
        'text-tertiary': '#718096',
        'text-muted': '#A0AEC0',
        'text-inverse': '#FFFFFF',
        
        // 办公级强调色 - 深蓝
        'accent': '#2563EB',
        'accent-hover': '#1D4ED8',
        'accent-light': 'rgba(37, 99, 235, 0.10)',
        'accent-glow': 'rgba(37, 99, 235, 0.15)',
        
        // 办公级状态色 - 鲜明
        'status-success': '#059669',
        'status-warning': '#D97706',
        'status-danger': '#DC2626',
        'status-info': '#2563EB',
        
        // 装饰色
        'mauve': '#8B5CF6',
        'sage': '#059669',
        'dusty-blue': '#3B82F6',
        'warm-gray': '#6B7280',
      },
      fontFamily: {
        'display': ['Outfit', 'sans-serif'],
        'body': ['"Noto Sans SC"', 'sans-serif'],
        'mono': ['"JetBrains Mono"', 'monospace'],
      },
      borderRadius: {
        'sm': '8px',
        'md': '12px',
        'lg': '16px',
        'xl': '24px',
        '2xl': '32px',
      },
      boxShadow: {
        'sm': '0 1px 3px rgba(61, 58, 54, 0.06), 0 1px 2px rgba(61, 58, 54, 0.04)',
        'md': '0 4px 16px rgba(61, 58, 54, 0.08), 0 2px 8px rgba(61, 58, 54, 0.04)',
        'lg': '0 8px 32px rgba(61, 58, 54, 0.10), 0 4px 16px rgba(61, 58, 54, 0.06)',
        'glass': '0 8px 32px rgba(61, 58, 54, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.6)',
        'glow': '0 0 40px rgba(122, 139, 153, 0.12)',
        'layer': '0 2px 8px rgba(61, 58, 54, 0.06), 0 8px 24px rgba(61, 58, 54, 0.04)',
      },
      backdropBlur: {
        'glass': '20px',
      },
      animation: {
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'fade-in': 'fade-in 300ms ease-out',
        'slide-up': 'slide-up 350ms cubic-bezier(0.16, 1, 0.3, 1)',
        'float': 'float 6s ease-in-out infinite',
        'shimmer': 'shimmer 2s ease-in-out infinite',
      },
      keyframes: {
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(143, 174, 143, 0.3)' },
          '50%': { boxShadow: '0 0 0 10px rgba(143, 174, 143, 0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'slide-up': {
          '0%': { opacity: '0', transform: 'translateY(24px) scale(0.97)' },
          '100%': { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-6px)' },
        },
        'shimmer': {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
    },
  },
  plugins: [],
};
