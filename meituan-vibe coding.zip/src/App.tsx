import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import ToastContainer from './components/Toast';
import ReminderToast from './components/ReminderToast';
import Dashboard from './pages/Dashboard';
import MeetingList from './pages/MeetingList';
import MeetingDetail from './pages/MeetingDetail';
import CreateMeeting from './pages/CreateMeeting';
import EditMeeting from './pages/EditMeeting';
import MyTodos from './pages/MyTodos';
import Templates from './pages/Templates';

function App() {
  return (
    <BrowserRouter>
      <div className="flex min-h-screen bg-bg-base">
        <Sidebar />
        <main className="flex-1 ml-[220px]">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/meetings" element={<MeetingList />} />
            <Route path="/meetings/new" element={<CreateMeeting />} />
            <Route path="/meetings/:id" element={<MeetingDetail />} />
            <Route path="/meetings/:id/edit" element={<EditMeeting />} />
            <Route path="/todos" element={<MyTodos />} />
            <Route path="/templates" element={<Templates />} />
          </Routes>
        </main>
        <ToastContainer />
        <ReminderToast />
      </div>
    </BrowserRouter>
  );
}

export default App;
