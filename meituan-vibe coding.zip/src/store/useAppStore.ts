import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Meeting, AgendaItem, Note, ActionItem, MeetingStatus } from '../types';
import { generateId, getCurrentTime } from '../utils/dateUtils';
import { mockMeetings, mockAgendaItems, mockNotes, mockActionItems } from '../utils/mockData';

interface AppStore {
  meetings: Meeting[];
  agendaItems: AgendaItem[];
  notes: Note[];
  actionItems: ActionItem[];

  addMeeting: (meeting: Omit<Meeting, 'id' | 'createdAt' | 'updatedAt' | 'reminders'>) => void;
  updateMeeting: (id: string, data: Partial<Meeting>) => void;
  deleteMeeting: (id: string) => void;

  addAgendaItem: (item: Omit<AgendaItem, 'id'>) => void;
  updateAgendaItem: (id: string, data: Partial<AgendaItem>) => void;
  deleteAgendaItem: (id: string) => void;

  addNote: (note: Omit<Note, 'id' | 'createdAt'>) => void;
  deleteNote: (id: string) => void;

  addActionItem: (item: Omit<ActionItem, 'id' | 'createdAt'>) => void;
  updateActionItem: (id: string, data: Partial<ActionItem>) => void;
  deleteActionItem: (id: string) => void;

  generateSummary: (meetingId: string) => string;
  checkReminders: () => Meeting[];
  markReminderNotified: (meetingId: string, reminderId: string) => void;
}

const hasStoredData = () => {
  try {
    const data = localStorage.getItem('meeting-assistant-storage');
    return data !== null;
  } catch {
    return false;
  }
};

export const useAppStore = create<AppStore>()(
  persist(
    (set, get) => ({
      meetings: hasStoredData() ? [] : mockMeetings,
      agendaItems: hasStoredData() ? [] : mockAgendaItems,
      notes: hasStoredData() ? [] : mockNotes,
      actionItems: hasStoredData() ? [] : mockActionItems,

      addMeeting: (meeting) => {
        const id = generateId();
        const newMeeting: Meeting = {
          ...meeting,
          id,
          reminders: [
            { id: generateId(), meetingId: id, minutesBefore: 15, notified: false },
            { id: generateId(), meetingId: id, minutesBefore: 5, notified: false },
          ],
          createdAt: getCurrentTime(),
          updatedAt: getCurrentTime(),
        };
        set((state) => ({ meetings: [...state.meetings, newMeeting] }));
      },

      updateMeeting: (id, data) => {
        set((state) => ({
          meetings: state.meetings.map((m) =>
            m.id === id ? { ...m, ...data, updatedAt: getCurrentTime() } : m
          ),
        }));
      },

      deleteMeeting: (id) => {
        set((state) => ({
          meetings: state.meetings.filter((m) => m.id !== id),
          agendaItems: state.agendaItems.filter((a) => a.meetingId !== id),
          notes: state.notes.filter((n) => n.meetingId !== id),
          actionItems: state.actionItems.filter((a) => a.meetingId !== id),
        }));
      },

      addAgendaItem: (item) => {
        const newItem: AgendaItem = { ...item, id: generateId() };
        set((state) => ({ agendaItems: [...state.agendaItems, newItem] }));
      },

      updateAgendaItem: (id, data) => {
        set((state) => ({
          agendaItems: state.agendaItems.map((a) =>
            a.id === id ? { ...a, ...data } : a
          ),
        }));
      },

      deleteAgendaItem: (id) => {
        set((state) => ({
          agendaItems: state.agendaItems.filter((a) => a.id !== id),
        }));
      },

      addNote: (note) => {
        const newNote: Note = { ...note, id: generateId(), createdAt: getCurrentTime() };
        set((state) => ({ notes: [...state.notes, newNote] }));
      },

      deleteNote: (id) => {
        set((state) => ({ notes: state.notes.filter((n) => n.id !== id) }));
      },

      addActionItem: (item) => {
        const newItem: ActionItem = { ...item, id: generateId(), createdAt: getCurrentTime() };
        set((state) => ({ actionItems: [...state.actionItems, newItem] }));
      },

      updateActionItem: (id, data) => {
        set((state) => ({
          actionItems: state.actionItems.map((a) =>
            a.id === id ? { ...a, ...data } : a
          ),
        }));
      },

      deleteActionItem: (id) => {
        set((state) => ({
          actionItems: state.actionItems.filter((a) => a.id !== id),
        }));
      },

      generateSummary: (meetingId) => {
        const state = get();
        const meeting = state.meetings.find((m) => m.id === meetingId);
        const agenda = state.agendaItems.filter((a) => a.meetingId === meetingId).sort((a, b) => a.order - b.order);
        const notes = state.notes.filter((n) => n.meetingId === meetingId);

        if (!meeting) return '';

        const agendaStr = agenda.map((a, i) => `${i + 1}. ${a.topic} (${a.duration}分钟) - ${a.owner}`).join('\n');
        const notesStr = notes.map((n) => {
          const tagMap = { decision: '【决策】', todo: '【待办】', question: '【问题】', general: '' };
          return `- ${tagMap[n.tag]}${n.content}`;
        }).join('\n');

        const summary = `# 会议纪要：${meeting.title}

## 会议信息
- 时间：${meeting.startTime.slice(0, 16).replace('T', ' ')} - ${meeting.endTime.slice(0, 16).replace('T', ' ')}
- 参会人：${meeting.attendees.join('、')}

## 议程回顾
${agendaStr || '（无议程）'}

## 讨论要点
${notesStr || '（无速记内容）'}

## 核心结论
（请在此补充核心结论）

## 待办事项
（请在此补充待办事项）`;

        set((state) => ({
          meetings: state.meetings.map((m) =>
            m.id === meetingId ? { ...m, summary, status: 'pending_confirm' as MeetingStatus, updatedAt: getCurrentTime() } : m
          ),
        }));

        return summary;
      },

      checkReminders: () => {
        const state = get();
        const now = new Date().getTime();
        const dueMeetings: Meeting[] = [];

        state.meetings.forEach((meeting) => {
          if (meeting.status === 'cancelled' || meeting.status === 'completed') return;
          
          const startTime = new Date(meeting.startTime).getTime();
          meeting.reminders.forEach((reminder) => {
            if (reminder.notified) return;
            
            const reminderTime = startTime - reminder.minutesBefore * 60 * 1000;
            if (now >= reminderTime && now < startTime) {
              dueMeetings.push(meeting);
            }
          });
        });

        return dueMeetings;
      },

      markReminderNotified: (meetingId, reminderId) => {
        set((state) => ({
          meetings: state.meetings.map((m) =>
            m.id === meetingId
              ? {
                  ...m,
                  reminders: m.reminders.map((r) =>
                    r.id === reminderId ? { ...r, notified: true } : r
                  ),
                }
              : m
          ),
        }));
      },
    }),
    {
      name: 'meeting-assistant-storage',
    }
  )
);
