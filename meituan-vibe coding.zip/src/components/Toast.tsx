import { useEffect, useState } from 'react';
import { CheckCircle, X, AlertCircle, Info } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'info';

interface ToastItem {
  id: string;
  message: string;
  type: ToastType;
}

let toastListeners: ((toasts: ToastItem[]) => void)[] = [];
let toasts: ToastItem[] = [];

function notify() {
  toastListeners.forEach((listener) => listener([...toasts]));
}

export function showToast(message: string, type: ToastType = 'info') {
  const id = Math.random().toString(36).substring(2, 9);
  toasts = [...toasts, { id, message, type }];
  notify();

  setTimeout(() => {
    toasts = toasts.filter((t) => t.id !== id);
    notify();
  }, 3000);
}

export default function ToastContainer() {
  const [items, setItems] = useState<ToastItem[]>([]);

  useEffect(() => {
    const listener = (newToasts: ToastItem[]) => setItems(newToasts);
    toastListeners.push(listener);
    return () => {
      toastListeners = toastListeners.filter((l) => l !== listener);
    };
  }, []);

  return (
    <div className="fixed top-6 right-6 z-[100] flex flex-col gap-3">
      {items.map((toast) => {
        const iconMap = {
          success: <CheckCircle size={16} className="text-status-success" strokeWidth={2} />,
          error: <AlertCircle size={16} className="text-status-danger" strokeWidth={2} />,
          info: <Info size={16} className="text-status-info" strokeWidth={2} />,
        };

        const bgMap = {
          success: 'bg-status-success/8 border-status-success/15',
          error: 'bg-status-danger/8 border-status-danger/15',
          info: 'bg-status-info/8 border-status-info/15',
        };

        return (
          <div
            key={toast.id}
            className={`flex items-center gap-3 px-5 py-3.5 rounded-xl border shadow-lg backdrop-blur-sm animate-slide-up ${bgMap[toast.type]}`}
          >
            {iconMap[toast.type]}
            <span className="text-sm font-medium text-text-primary">{toast.message}</span>
            <button
              onClick={() => {
                toasts = toasts.filter((t) => t.id !== toast.id);
                notify();
              }}
              className="ml-2 text-text-muted hover:text-text-secondary transition-colors"
            >
              <X size={14} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
