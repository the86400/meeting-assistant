import { NavLink } from 'react-router-dom';
import { LayoutDashboard, CalendarDays, CheckSquare, FileText } from 'lucide-react';

const navItems = [
  { path: '/', label: '会议概览', icon: LayoutDashboard },
  { path: '/meetings', label: '会议列表', icon: CalendarDays },
  { path: '/todos', label: '我的待办', icon: CheckSquare },
  { path: '/templates', label: '纪要模板', icon: FileText },
];

export default function Sidebar() {
  return (
    <aside className="w-[220px] min-h-screen bg-bg-surface/80 backdrop-blur-glass border-r border-text-muted/10 flex flex-col fixed left-0 top-0 z-50">
      <div className="px-6 py-8">
        <h1 className="font-display text-xl font-bold text-text-primary tracking-tight">
          会议助手
        </h1>
        <p className="text-xs text-text-tertiary mt-1.5 font-light tracking-wide">Meeting Assistant</p>
      </div>

      <nav className="flex-1 px-4 py-2 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                  isActive
                    ? 'bg-accent-light text-accent shadow-sm'
                    : 'text-text-secondary hover:bg-bg-hover hover:text-text-primary'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <Icon size={18} strokeWidth={isActive ? 2 : 1.5} />
                  <span>{item.label}</span>
                </>
              )}
            </NavLink>
          );
        })}
      </nav>

      <div className="px-6 py-5 border-t border-text-muted/10">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-status-success animate-pulse-glow" />
          <p className="text-xs text-text-muted">视频会议助手 v1.0</p>
        </div>
      </div>
    </aside>
  );
}
