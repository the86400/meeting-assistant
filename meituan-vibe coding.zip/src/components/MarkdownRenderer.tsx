interface MarkdownRendererProps {
  content: string;
}

export default function MarkdownRenderer({ content }: MarkdownRendererProps) {
  const renderMarkdown = (text: string) => {
    const lines = text.split('\n');
    const elements: JSX.Element[] = [];
    let key = 0;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      if (line.startsWith('# ')) {
        elements.push(
          <h1 key={key++} className="text-xl font-bold text-text-primary mt-6 mb-3 first:mt-0">
            {line.slice(2)}
          </h1>
        );
      } else if (line.startsWith('## ')) {
        elements.push(
          <h2 key={key++} className="text-lg font-semibold text-text-primary mt-5 mb-2">
            {line.slice(3)}
          </h2>
        );
      } else if (line.startsWith('### ')) {
        elements.push(
          <h3 key={key++} className="text-base font-semibold text-text-primary mt-4 mb-2">
            {line.slice(4)}
          </h3>
        );
      } else if (line.startsWith('- ')) {
        const checkboxMatch = line.match(/^- \[(.)\] (.+)/);
        if (checkboxMatch) {
          const isChecked = checkboxMatch[1] === 'x' || checkboxMatch[1] === 'X';
          elements.push(
            <div key={key++} className="flex items-start gap-2 ml-4 my-1">
              <span className={`mt-1 w-4 h-4 rounded border flex items-center justify-center text-xs ${
                isChecked ? 'bg-accent border-accent text-bg-base' : 'border-text-muted'
              }`}>
                {isChecked && '✓'}
              </span>
              <span className={`text-sm ${isChecked ? 'text-text-muted line-through' : 'text-text-primary'}`}>
                {checkboxMatch[2]}
              </span>
            </div>
          );
        } else {
          elements.push(
            <li key={key++} className="text-sm text-text-primary ml-4 my-1 list-disc list-inside">
              {line.slice(2)}
            </li>
          );
        }
      } else if (line.match(/^\d+\.\s/)) {
        elements.push(
          <li key={key++} className="text-sm text-text-primary ml-4 my-1 list-decimal list-inside">
            {line.replace(/^\d+\.\s/, '')}
          </li>
        );
      } else if (line.trim() === '') {
        elements.push(<div key={key++} className="h-2" />);
      } else {
        elements.push(
          <p key={key++} className="text-sm text-text-primary my-1 leading-relaxed">
            {line}
          </p>
        );
      }
    }

    return elements;
  };

  return (
    <div className="markdown-content">
      {renderMarkdown(content)}
    </div>
  );
}
