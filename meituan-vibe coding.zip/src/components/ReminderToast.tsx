import { useEffect, useRef } from 'react';
import { Bell, Clock, ArrowRight } from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import { showToast } from './Toast';
import { useNavigate } from 'react-router-dom';

export default function ReminderToast() {
  const navigate = useNavigate();
  const checkReminders = useAppStore((s) => s.checkReminders);
  const markReminderNotified = useAppStore((s) => s.markReminderNotified);
  const meetings = useAppStore((s) => s.meetings);
  const notifiedRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    const interval = setInterval(() => {
      const dueMeetings = checkReminders();
      
      dueMeetings.forEach((meeting) => {
        meeting.reminders.forEach((reminder) => {
          const key = `${meeting.id}-${reminder.id}`;
          
          if (reminder.notified || notifiedRef.current.has(key)) return;
          
          const startTime = new Date(meeting.startTime);
          const now = new Date();
          const minutesUntil = Math.ceil((startTime.getTime() - now.getTime()) / (1000 * 60));
          
          if (minutesUntil > 0 && minutesUntil <= reminder.minutesBefore) {
            notifiedRef.current.add(key);
            markReminderNotified(meeting.id, reminder.id);
            
            showToast(
              `「${meeting.title}」将在 ${minutesUntil} 分钟后开始`,
              'info'
            );
          }
        });
      });
    }, 30000); // 每 30 秒检查一次

    return () => clearInterval(interval);
  }, [checkReminders, markReminderNotified, meetings]);

  return null;
}
