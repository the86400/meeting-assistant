import { CalendarOff, CheckCircle2, FileText, SearchX, Plus, Sparkles } from 'lucide-react';

interface EmptyStateProps {
  type: 'meetings' | 'todos' | 'summary' | 'search';
  onAction?: () => void;
}

const configs = {
  meetings: {
    icon: CalendarOff,
    title: '还没有会议',
    description: '创建你的第一个会议，开始高效协作',
    actionLabel: '创建会议',
  },
  todos: {
    icon: CheckCircle2,
    title: '暂无待办',
    description: '会议中的 Action Items 会出现在这里',
    actionLabel: null,
  },
  summary: {
    icon: FileText,
    title: '暂无纪要',
    description: '会议结束后可以生成结构化纪要',
    actionLabel: '去生成纪要',
  },
  search: {
    icon: SearchX,
    title: '未找到相关会议',
    description: '尝试调整搜索关键词',
    actionLabel: '清除搜索',
  },
};

export default function EmptyState({ type, onAction }: EmptyStateProps) {
  const config = configs[type];
  const Icon = config.icon;

  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="relative mb-6">
        <div className="w-20 h-20 rounded-2xl bg-accent-light flex items-center justify-center">
          <Icon size={32} className="text-accent" strokeWidth={1.5} />
        </div>
        <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-bg-surface flex items-center justify-center shadow-sm">
          <Sparkles size={12} className="text-accent" />
        </div>
      </div>
      <h3 className="text-base font-semibold text-text-primary mb-2">{config.title}</h3>
      <p className="text-sm text-text-tertiary mb-6 max-w-[240px]">{config.description}</p>
      {config.actionLabel && onAction && (
        <button
          onClick={onAction}
          className="inline-flex items-center gap-2 px-6 py-3 bg-accent text-text-inverse rounded-xl text-sm font-semibold hover:brightness-110 transition-all duration-150 btn-scale shadow-glow"
        >
          <Plus size={16} />
          {config.actionLabel}
        </button>
      )}
    </div>
  );
}
