import type { MeetingStatus } from '../types';

const statusConfig: Record<MeetingStatus, { label: string; color: string; bgColor: string; dot?: boolean; pulse?: boolean }> = {
  upcoming: { label: '待开始', color: 'text-status-info', bgColor: 'bg-status-info/8', dot: true },
  ongoing: { label: '进行中', color: 'text-status-success', bgColor: 'bg-status-success/8', dot: true, pulse: true },
  pending_summary: { label: '待生成纪要', color: 'text-status-warning', bgColor: 'bg-status-warning/8', dot: true },
  pending_confirm: { label: '待确认', color: 'text-status-warning', bgColor: 'bg-status-warning/8', dot: true },
  completed: { label: '已完成', color: 'text-text-muted', bgColor: 'bg-text-muted/8' },
  cancelled: { label: '已取消', color: 'text-text-muted', bgColor: 'bg-text-muted/8', dot: false },
};

interface StatusBadgeProps {
  status: MeetingStatus;
  size?: 'sm' | 'md';
}

export default function StatusBadge({ status, size = 'sm' }: StatusBadgeProps) {
  const config = statusConfig[status];
  const sizeClasses = size === 'sm' ? 'px-2.5 py-1 text-xs' : 'px-3 py-1.5 text-sm';

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-lg font-medium ${sizeClasses} ${config.bgColor} ${config.color}`}>
      {config.dot && (
        <span
          className={`w-1.5 h-1.5 rounded-full ${
            status === 'ongoing' ? 'bg-status-success animate-pulse-glow' :
            status === 'upcoming' ? 'bg-status-info' :
            status === 'pending_summary' || status === 'pending_confirm' ? 'bg-status-warning' :
            'bg-text-muted'
          }`}
        />
      )}
      {config.label}
    </span>
  );
}
