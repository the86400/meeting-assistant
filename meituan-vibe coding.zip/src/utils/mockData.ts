import type { Meeting, AgendaItem, Note, ActionItem } from '../types';
import { generateId, getCurrentTime } from './dateUtils';

const now = new Date();
const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

function createDate(hours: number, minutes: number, dayOffset: number = 0): string {
  const d = new Date(today);
  d.setDate(d.getDate() + dayOffset);
  d.setHours(hours, minutes, 0, 0);
  return d.toISOString();
}

function createReminders(meetingId: string): Meeting['reminders'] {
  return [
    { id: generateId(), meetingId, minutesBefore: 15, notified: false },
    { id: generateId(), meetingId, minutesBefore: 5, notified: false },
  ];
}

export const mockMeetings: Meeting[] = [
  {
    id: generateId(),
    title: '产品周会',
    description: '讨论本周产品迭代进展和下周计划',
    startTime: createDate(10, 0),
    endTime: createDate(11, 0),
    meetingLink: 'https://meet.example.com/abc123',
    attendees: ['张三', '李四', '王五', '赵六'],
    status: 'upcoming',
    summary: '',
    reminders: createReminders(''),
    createdAt: getCurrentTime(),
    updatedAt: getCurrentTime(),
  },
  {
    id: generateId(),
    title: '技术评审：AI 纪要功能',
    description: '评审 AI 会议纪要生成方案的技术可行性',
    startTime: createDate(14, 0, 1),
    endTime: createDate(15, 30, 1),
    meetingLink: 'https://meet.example.com/def456',
    attendees: ['张三', '李四', '王五'],
    status: 'upcoming',
    summary: '',
    reminders: createReminders(''),
    createdAt: getCurrentTime(),
    updatedAt: getCurrentTime(),
  },
  {
    id: generateId(),
    title: 'Q3 季度规划讨论',
    description: '讨论 Q3 季度产品目标和资源分配',
    startTime: createDate(9, 30, -1),
    endTime: createDate(11, 0, -1),
    meetingLink: 'https://meet.example.com/ghi789',
    attendees: ['张三', '李四', '王五', '赵六', '钱七'],
    status: 'pending_summary',
    summary: '',
    reminders: createReminders(''),
    createdAt: getCurrentTime(),
    updatedAt: getCurrentTime(),
  },
  {
    id: generateId(),
    title: '设计评审：会议助手 UI',
    description: '评审会议助手工具的视觉设计方案',
    startTime: createDate(16, 0, -3),
    endTime: createDate(17, 0, -3),
    meetingLink: 'https://meet.example.com/jkl012',
    attendees: ['张三', '王五'],
    status: 'completed',
    summary: '## 会议纪要：设计评审\n\n### 会议信息\n- 时间：2026-05-14 16:00 - 17:00\n- 参会人：张三、王五\n\n### 核心结论\n1. 采用暗色主题 + 香槟金强调色\n2. 卡片式布局，顶部微光效果\n3. 左侧 Sidebar 导航，右侧内容区\n\n### 待办事项\n- [ ] 张三：完成高保真原型图\n- [ ] 王五：准备设计规范文档',
    reminders: createReminders(''),
    createdAt: getCurrentTime(),
    updatedAt: getCurrentTime(),
  },
];

export const mockAgendaItems: AgendaItem[] = [
  { id: generateId(), meetingId: mockMeetings[0].id, topic: '上周迭代回顾', duration: 15, owner: '张三', order: 0 },
  { id: generateId(), meetingId: mockMeetings[0].id, topic: '本周进度同步', duration: 20, owner: '李四', order: 1 },
  { id: generateId(), meetingId: mockMeetings[0].id, topic: '下周计划讨论', duration: 20, owner: '王五', order: 2 },
  { id: generateId(), meetingId: mockMeetings[0].id, topic: '问题与风险', duration: 5, owner: '赵六', order: 3 },
  { id: generateId(), meetingId: mockMeetings[1].id, topic: '技术方案介绍', duration: 20, owner: '张三', order: 0 },
  { id: generateId(), meetingId: mockMeetings[1].id, topic: '可行性评估', duration: 30, owner: '李四', order: 1 },
  { id: generateId(), meetingId: mockMeetings[1].id, topic: '排期与资源', duration: 20, owner: '王五', order: 2 },
  { id: generateId(), meetingId: mockMeetings[2].id, topic: 'Q2 回顾', duration: 15, owner: '张三', order: 0 },
  { id: generateId(), meetingId: mockMeetings[2].id, topic: 'Q3 目标设定', duration: 30, owner: '李四', order: 1 },
  { id: generateId(), meetingId: mockMeetings[2].id, topic: '资源分配', duration: 20, owner: '王五', order: 2 },
];

export const mockNotes: Note[] = [
  { id: generateId(), meetingId: mockMeetings[2].id, content: 'Q2 用户增长目标超额完成 120%', tag: 'decision', createdAt: getCurrentTime() },
  { id: generateId(), meetingId: mockMeetings[2].id, content: 'Q3 需要新增 2 名后端工程师', tag: 'todo', createdAt: getCurrentTime() },
  { id: generateId(), meetingId: mockMeetings[2].id, content: '移动端体验优化优先级是否提升？', tag: 'question', createdAt: getCurrentTime() },
];

export const mockActionItems: ActionItem[] = [
  { id: generateId(), meetingId: mockMeetings[3].id, content: '完成高保真原型图', assignee: '张三', status: 'in_progress', dueDate: createDate(18, 0, 2).split('T')[0], createdAt: getCurrentTime() },
  { id: generateId(), meetingId: mockMeetings[3].id, content: '准备设计规范文档', assignee: '王五', status: 'todo', dueDate: createDate(18, 0, 3).split('T')[0], createdAt: getCurrentTime() },
  { id: generateId(), meetingId: mockMeetings[2].id, content: '整理 Q3 资源需求清单', assignee: '李四', status: 'todo', dueDate: createDate(18, 0, 1).split('T')[0], createdAt: getCurrentTime() },
];
