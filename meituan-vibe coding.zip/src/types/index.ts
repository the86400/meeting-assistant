export type MeetingStatus = 'upcoming' | 'ongoing' | 'pending_summary' | 'pending_confirm' | 'completed' | 'cancelled';

export interface MeetingReminder {
  id: string;
  meetingId: string;
  minutesBefore: number;
  notified: boolean;
}

export interface Meeting {
  id: string;
  title: string;
  description: string;
  startTime: string;
  endTime: string;
  meetingLink: string;
  attendees: string[];
  status: MeetingStatus;
  summary: string;
  reminders: MeetingReminder[];
  createdAt: string;
  updatedAt: string;
}

export interface AgendaItem {
  id: string;
  meetingId: string;
  topic: string;
  duration: number;
  owner: string;
  order: number;
}

export interface Note {
  id: string;
  meetingId: string;
  content: string;
  tag: 'decision' | 'todo' | 'question' | 'general';
  createdAt: string;
}

export interface ActionItem {
  id: string;
  meetingId: string;
  content: string;
  assignee: string;
  status: 'todo' | 'in_progress' | 'done';
  dueDate: string;
  createdAt: string;
}

export interface AppState {
  meetings: Meeting[];
  agendaItems: AgendaItem[];
  notes: Note[];
  actionItems: ActionItem[];
}
