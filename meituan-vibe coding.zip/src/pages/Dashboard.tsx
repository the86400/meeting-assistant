import { useNavigate } from 'react-router-dom';
import { CalendarDays, FileText, Plus, Clock, ArrowRight } from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import StatusBadge from '../components/StatusBadge';
import EmptyState from '../components/EmptyState';
import { formatDateTime, formatTime } from '../utils/dateUtils';

export default function Dashboard() {
  const navigate = useNavigate();
  const meetings = useAppStore((s) => s.meetings);
  const todayMeetings = meetings
    .filter((m) => {
      const start = new Date(m.startTime);
      const today = new Date();
      return start.toDateString() === today.toDateString() && m.status !== 'cancelled';
    })
    .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());

  const pendingSummaries = meetings.filter((m) => m.status === 'pending_summary');

  const stats = [
    {
      label: '今日会议',
      value: todayMeetings.length,
      icon: CalendarDays,
      color: 'text-status-info',
    },
    {
      label: '待生成纪要',
      value: pendingSummaries.length,
      icon: FileText,
      color: 'text-accent',
    },
    {
      label: '本周会议',
      value: meetings.filter((m) => {
        const start = new Date(m.startTime);
        const now = new Date();
        const weekEnd = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        return start >= now && start <= weekEnd && m.status !== 'cancelled';
      }).length,
      icon: CalendarDays,
      color: 'text-status-success',
    },
  ];

  return (
    <div className="p-10 max-w-6xl animate-fade-in">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">会议概览</h1>
          <p className="text-sm text-text-tertiary mt-1">高效管理你的会议与待办</p>
        </div>
        <button
          onClick={() => navigate('/meetings/new')}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent text-bg-base rounded-sm text-sm font-semibold hover:brightness-110 transition-all duration-150 btn-scale shadow-glow"
        >
          <Plus size={16} />
          创建会议
        </button>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-3 gap-5 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="card-shimmer bg-bg-surface rounded-lg border border-white/[0.04] shadow-md p-5 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-display text-3xl font-bold text-text-primary">{stat.value}</p>
                  <p className="text-sm text-text-tertiary mt-1">{stat.label}</p>
                </div>
                <div className={`w-10 h-10 rounded-md ${stat.color.replace('text-', 'bg-')}/10 flex items-center justify-center`}>
                  <Icon size={20} className={stat.color} strokeWidth={1.5} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* 今日会议 */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-text-primary">今日会议</h2>
          <button
            onClick={() => navigate('/meetings')}
            className="inline-flex items-center gap-1 text-sm text-accent hover:text-accent-hover transition-colors"
          >
            查看全部
            <ArrowRight size={14} />
          </button>
        </div>

        {todayMeetings.length === 0 ? (
          <div className="bg-bg-surface rounded-lg border border-white/[0.04]">
            <EmptyState type="meetings" onAction={() => navigate('/meetings/new')} />
          </div>
        ) : (
          <div className="space-y-3">
            {todayMeetings.map((meeting, index) => (
              <div
                key={meeting.id}
                onClick={() => navigate(`/meetings/${meeting.id}`)}
                className="flex items-center gap-4 bg-bg-surface rounded-lg border border-white/[0.04] p-4 hover:bg-bg-elevated hover:border-white/[0.08] hover:-translate-y-0.5 hover:shadow-md transition-all duration-200 cursor-pointer group"
                style={{ animationDelay: `${index * 40}ms` }}
              >
                <div className="flex flex-col items-center min-w-[60px]">
                  <span className="font-mono text-sm font-medium text-text-primary">
                    {formatTime(meeting.startTime)}
                  </span>
                  <span className="text-xs text-text-tertiary">
                    {formatTime(meeting.endTime)}
                  </span>
                </div>
                <div className="w-px h-10 bg-white/[0.06]" />
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-semibold text-text-primary truncate group-hover:text-accent transition-colors">{meeting.title}</h3>
                  <p className="text-xs text-text-tertiary mt-0.5 truncate">{meeting.description}</p>
                </div>
                <StatusBadge status={meeting.status} />
                <div className="flex -space-x-2">
                  {meeting.attendees.slice(0, 3).map((name, i) => (
                    <div
                      key={i}
                      className="w-7 h-7 rounded-full bg-bg-elevated border border-bg-surface flex items-center justify-center text-xs text-text-secondary"
                    >
                      {name[0]}
                    </div>
                  ))}
                  {meeting.attendees.length > 3 && (
                    <div className="w-7 h-7 rounded-full bg-bg-elevated border border-bg-surface flex items-center justify-center text-xs text-text-tertiary">
                      +{meeting.attendees.length - 3}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 快捷入口 */}
      <div className="grid grid-cols-2 gap-5">
        <div
          onClick={() => navigate('/templates')}
          className="bg-bg-surface rounded-lg border border-white/[0.04] p-5 hover:bg-bg-elevated hover:border-white/[0.08] transition-all duration-200 cursor-pointer"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-md bg-accent/10 flex items-center justify-center">
              <FileText size={20} className="text-accent" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-text-primary">纪要模板</h3>
              <p className="text-xs text-text-tertiary">快速生成结构化纪要</p>
            </div>
          </div>
        </div>

        <div
          onClick={() => navigate('/meetings')}
          className="bg-bg-surface rounded-lg border border-white/[0.04] p-5 hover:bg-bg-elevated hover:border-white/[0.08] transition-all duration-200 cursor-pointer"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-md bg-status-info/10 flex items-center justify-center">
              <Clock size={20} className="text-status-info" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-text-primary">待生成纪要</h3>
              <p className="text-xs text-text-tertiary">{pendingSummaries.length} 个会议等待整理</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
