import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit2, Trash2, XCircle, Link2, Users, Clock, FileText, Send, CheckCircle, CheckSquare, Square, Play, RotateCcw } from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import StatusBadge from '../components/StatusBadge';
import EmptyState from '../components/EmptyState';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { showToast } from '../components/Toast';
import { formatDateTime, formatTime } from '../utils/dateUtils';

const tabs = [
  { key: 'info', label: '信息' },
  { key: 'agenda', label: '议程' },
  { key: 'notes', label: '速记' },
  { key: 'summary', label: '纪要' },
  { key: 'todos', label: '待办' },
];

export default function MeetingDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('info');

  const meeting = useAppStore((s) => s.meetings.find((m) => m.id === id));
  const agendaItems = useAppStore((s) => s.agendaItems.filter((a) => a.meetingId === id).sort((a, b) => a.order - b.order));
  const notes = useAppStore((s) => s.notes.filter((n) => n.meetingId === id));
  const actionItems = useAppStore((s) => s.actionItems.filter((a) => a.meetingId === id));

  const updateMeeting = useAppStore((s) => s.updateMeeting);
  const deleteMeeting = useAppStore((s) => s.deleteMeeting);
  const generateSummary = useAppStore((s) => s.generateSummary);
  const addNote = useAppStore((s) => s.addNote);
  const addActionItem = useAppStore((s) => s.addActionItem);
  const updateActionItem = useAppStore((s) => s.updateActionItem);

  const [noteContent, setNoteContent] = useState('');
  const [noteTag, setNoteTag] = useState<'decision' | 'todo' | 'question' | 'general'>('general');
  const [editingSummary, setEditingSummary] = useState(false);
  const [summaryText, setSummaryText] = useState('');

  if (!meeting) {
    return (
      <div className="p-10">
        <p className="text-text-secondary">会议不存在</p>
      </div>
    );
  }

  const handleDelete = () => {
    if (confirm('确定要删除这个会议吗？')) {
      deleteMeeting(meeting.id);
      showToast('会议已删除', 'info');
      navigate('/meetings');
    }
  };

  const handleCancel = () => {
    if (confirm('确定要取消这个会议吗？')) {
      updateMeeting(meeting.id, { status: 'cancelled' });
      showToast('会议已取消', 'info');
    }
  };

  const handleGenerateSummary = () => {
    const summary = generateSummary(meeting.id);
    setSummaryText(summary);
    setEditingSummary(true);
  };

  const handleConfirmSummary = () => {
    updateMeeting(meeting.id, {
      summary: summaryText,
      status: 'completed',
    });
    setEditingSummary(false);
    showToast('纪要已发布', 'success');

    // 从纪要中提取待办（简单规则：包含【待办】或 todo 标记的行）
    const lines = summaryText.split('\n');
    lines.forEach((line) => {
      const match = line.match(/^-\s*\[?\s*\]?\s*(.+)/);
      if (match && (line.includes('待办') || line.includes('TODO') || line.includes('todo'))) {
        addActionItem({
          meetingId: meeting.id,
          content: match[1].replace(/【待办】|TODO|todo/g, '').trim(),
          assignee: '待定',
          status: 'todo',
          dueDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
        });
      }
    });
  };

  const handleAddNote = () => {
    if (!noteContent.trim()) return;
    addNote({
      meetingId: meeting.id,
      content: noteContent,
      tag: noteTag,
    });
    setNoteContent('');
    showToast('速记已添加', 'success');
  };

  const cycleTodoStatus = (itemId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'todo' ? 'in_progress' : currentStatus === 'in_progress' ? 'done' : 'todo';
    updateActionItem(itemId, { status: nextStatus });
    const statusText = nextStatus === 'todo' ? '待办' : nextStatus === 'in_progress' ? '进行中' : '已完成';
    showToast(`状态已更新为「${statusText}」`, 'success');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'done':
        return <CheckSquare size={18} className="text-status-success" />;
      case 'in_progress':
        return <Play size={18} className="text-status-info" />;
      default:
        return <Square size={18} className="text-status-warning" />;
    }
  };

  return (
    <div className="p-10 max-w-4xl animate-fade-in">
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-2 text-sm text-text-tertiary hover:text-text-secondary transition-colors mb-6"
      >
        <ArrowLeft size={16} />
        返回
      </button>

      {/* 会议头部 */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h1 className="font-display text-2xl font-bold text-text-primary">{meeting.title}</h1>
            <p className="text-sm text-text-tertiary mt-1">{meeting.description}</p>
          </div>
          <div className="flex items-center gap-2">
            {meeting.status !== 'cancelled' && meeting.status !== 'completed' && (
              <>
                <button
                  onClick={() => navigate(`/meetings/${meeting.id}/edit`)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-white/10 text-text-tertiary rounded-sm text-xs hover:bg-bg-hover transition-all"
                >
                  <Edit2 size={14} />
                  编辑
                </button>
                <button
                  onClick={handleCancel}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-white/10 text-text-tertiary rounded-sm text-xs hover:bg-bg-hover transition-all"
                >
                  <XCircle size={14} />
                  取消
                </button>
              </>
            )}
            <button
              onClick={handleDelete}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-status-danger/20 text-status-danger rounded-sm text-xs hover:bg-status-danger/10 transition-all"
            >
              <Trash2 size={14} />
              删除
            </button>
          </div>
        </div>

        <div className="flex items-center gap-4 flex-wrap">
          <StatusBadge status={meeting.status} size="md" />
          <div className="flex items-center gap-1.5 text-sm text-text-secondary">
            <Clock size={14} className="text-text-tertiary" />
            <span className="font-mono">{formatDateTime(meeting.startTime)}</span>
            <span className="text-text-muted">-</span>
            <span className="font-mono">{formatTime(meeting.endTime)}</span>
          </div>
          {meeting.meetingLink && (
            <a
              href={meeting.meetingLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm text-accent hover:text-accent-hover transition-colors"
            >
              <Link2 size={14} />
              会议链接
            </a>
          )}
          <div className="flex items-center gap-1.5 text-sm text-text-secondary">
            <Users size={14} className="text-text-tertiary" />
            {meeting.attendees.join('、')}
          </div>
        </div>
      </div>

      {/* 标签页 */}
      <div className="border-b border-white/[0.04] mb-6">
        <div className="flex items-center gap-1">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`px-4 py-3 text-sm font-medium transition-all duration-150 relative ${
                activeTab === tab.key
                  ? 'text-accent tab-indicator'
                  : 'text-text-tertiary hover:text-text-secondary'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* 内容区 */}
      <div className="min-h-[300px]">
        {activeTab === 'info' && (
          <div className="bg-bg-surface rounded-lg border border-white/[0.04] p-6 space-y-4">
            <div>
              <label className="text-xs text-text-tertiary">会议标题</label>
              <p className="text-sm text-text-primary mt-1">{meeting.title}</p>
            </div>
            <div>
              <label className="text-xs text-text-tertiary">会议描述</label>
              <p className="text-sm text-text-primary mt-1">{meeting.description || '（无描述）'}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-text-tertiary">开始时间</label>
                <p className="text-sm text-text-primary mt-1 font-mono">{formatDateTime(meeting.startTime)}</p>
              </div>
              <div>
                <label className="text-xs text-text-tertiary">结束时间</label>
                <p className="text-sm text-text-primary mt-1 font-mono">{formatDateTime(meeting.endTime)}</p>
              </div>
            </div>
            <div>
              <label className="text-xs text-text-tertiary">参会人</label>
              <div className="flex items-center gap-2 mt-2">
                {meeting.attendees.map((name, i) => (
                  <span
                    key={i}
                    className="inline-flex items-center px-2.5 py-1 rounded-full bg-bg-elevated text-xs text-text-secondary"
                  >
                    {name}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'agenda' && (
          <div className="space-y-3">
            {agendaItems.length === 0 ? (
              <EmptyState type="meetings" />
            ) : (
              agendaItems.map((item, index) => (
                <div
                  key={item.id}
                  className="flex items-center gap-4 bg-bg-surface rounded-lg border border-white/[0.04] p-4"
                >
                  <span className="text-xs text-text-muted w-6">{index + 1}</span>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-text-primary">{item.topic}</p>
                    <p className="text-xs text-text-tertiary mt-0.5">
                      {item.duration} 分钟 · 负责人：{item.owner}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'notes' && (
          <div className="space-y-4">
            <div className="bg-bg-surface rounded-lg border border-white/[0.04] p-4">
              <div className="flex items-center gap-2 mb-3">
                {(['general', 'decision', 'todo', 'question'] as const).map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setNoteTag(tag)}
                    className={`px-2.5 py-1 rounded-full text-xs font-medium transition-all ${
                      noteTag === tag
                        ? 'bg-accent/15 text-accent'
                        : 'bg-bg-elevated text-text-tertiary hover:text-text-secondary'
                    }`}
                  >
                    {tag === 'general' ? '普通' : tag === 'decision' ? '决策' : tag === 'todo' ? '待办' : '问题'}
                  </button>
                ))}
              </div>
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="记录会议中的关键内容..."
                rows={3}
                className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-2.5 text-sm text-text-primary placeholder:text-text-muted focus:outline-none input-glow transition-all duration-200 resize-none mb-3"
              />
              <div className="flex justify-end">
                <button
                  onClick={handleAddNote}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-accent text-bg-base rounded-sm text-xs font-semibold hover:brightness-110 transition-all btn-scale"
                >
                  <Send size={12} />
                  添加速记
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {notes.length === 0 ? (
                <p className="text-sm text-text-tertiary text-center py-8">暂无速记内容</p>
              ) : (
                notes.map((note) => (
                  <div
                    key={note.id}
                    className="bg-bg-surface rounded-lg border border-white/[0.04] p-4"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span
                        className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                          note.tag === 'decision'
                            ? 'bg-status-success/10 text-status-success'
                            : note.tag === 'todo'
                            ? 'bg-status-warning/10 text-status-warning'
                            : note.tag === 'question'
                            ? 'bg-status-info/10 text-status-info'
                            : 'bg-bg-elevated text-text-tertiary'
                        }`}
                      >
                        {note.tag === 'general' ? '普通' : note.tag === 'decision' ? '决策' : note.tag === 'todo' ? '待办' : '问题'}
                      </span>
                      <span className="text-xs text-text-muted">{new Date(note.createdAt).toLocaleTimeString('zh-CN')}</span>
                    </div>
                    <p className="text-sm text-text-primary">{note.content}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'summary' && (
          <div className="space-y-4">
            {!meeting.summary && !editingSummary ? (
              <div className="bg-bg-surface rounded-lg border border-white/[0.04] p-8 text-center">
                <FileText size={32} className="text-text-muted mx-auto mb-3" />
                <p className="text-sm text-text-secondary mb-1">暂无会议纪要</p>
                <p className="text-xs text-text-tertiary mb-4">基于议程和速记内容生成结构化纪要</p>
                <button
                  onClick={handleGenerateSummary}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent text-bg-base rounded-sm text-sm font-semibold hover:brightness-110 transition-all btn-scale shadow-glow"
                >
                  <FileText size={16} />
                  生成纪要
                </button>
              </div>
            ) : editingSummary ? (
              <div className="bg-bg-surface rounded-lg border border-white/[0.04] p-6">
                <textarea
                  value={summaryText}
                  onChange={(e) => setSummaryText(e.target.value)}
                  rows={20}
                  className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-3 text-sm text-text-primary font-mono leading-relaxed focus:outline-none input-glow transition-all duration-200 resize-none mb-4"
                />
                <div className="flex items-center justify-end gap-3">
                  <button
                    onClick={() => setEditingSummary(false)}
                    className="px-4 py-2 border border-white/10 text-text-secondary rounded-sm text-sm hover:bg-bg-hover transition-all"
                  >
                    取消
                  </button>
                  <button
                    onClick={handleConfirmSummary}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-accent text-bg-base rounded-sm text-sm font-semibold hover:brightness-110 transition-all btn-scale"
                  >
                    <CheckCircle size={14} />
                    确认发布
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-bg-surface rounded-lg border border-white/[0.04] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-text-primary">会议纪要</h3>
                  <button
                    onClick={() => {
                      setSummaryText(meeting.summary);
                      setEditingSummary(true);
                    }}
                    className="inline-flex items-center gap-1 text-xs text-accent hover:text-accent-hover transition-colors"
                  >
                    <Edit2 size={12} />
                    编辑
                  </button>
                </div>
                <div className="text-sm text-text-primary leading-relaxed">
                  <MarkdownRenderer content={meeting.summary} />
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'todos' && (
          <div className="space-y-3">
            {actionItems.length === 0 ? (
              <EmptyState type="todos" />
            ) : (
              actionItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => cycleTodoStatus(item.id, item.status)}
                  className="flex items-center gap-4 bg-bg-surface rounded-lg border border-white/[0.04] p-4 hover:bg-bg-elevated hover:border-white/[0.08] transition-all duration-200 cursor-pointer group"
                >
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      cycleTodoStatus(item.id, item.status);
                    }}
                    className="shrink-0 transition-transform group-hover:scale-110"
                  >
                    {getStatusIcon(item.status)}
                  </button>
                  <div className="flex-1">
                    <p className={`text-sm ${item.status === 'done' ? 'text-text-muted line-through' : 'text-text-primary'}`}>
                      {item.content}
                    </p>
                    <p className="text-xs text-text-tertiary mt-0.5">
                      负责人：{item.assignee} · 截止：{item.dueDate}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
