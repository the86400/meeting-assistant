import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, GripVertical } from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import { showToast } from '../components/Toast';
import { generateId } from '../utils/dateUtils';

interface AgendaFormItem {
  id: string;
  topic: string;
  duration: number;
  owner: string;
}

export default function EditMeeting() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const meeting = useAppStore((s) => s.meetings.find((m) => m.id === id));
  const allAgenda = useAppStore((s) => s.agendaItems.filter((a) => a.meetingId === id).sort((a, b) => a.order - b.order));
  const updateMeeting = useAppStore((s) => s.updateMeeting);
  const addAgendaItem = useAppStore((s) => s.addAgendaItem);
  const updateAgendaItem = useAppStore((s) => s.updateAgendaItem);
  const deleteAgendaItem = useAppStore((s) => s.deleteAgendaItem);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [meetingLink, setMeetingLink] = useState('');
  const [attendees, setAttendees] = useState('');
  const [agendaItems, setAgendaItems] = useState<AgendaFormItem[]>([]);

  useEffect(() => {
    if (!meeting) return;
    setTitle(meeting.title);
    setDescription(meeting.description);
    setStartTime(meeting.startTime.slice(0, 16));
    setEndTime(meeting.endTime.slice(0, 16));
    setMeetingLink(meeting.meetingLink);
    setAttendees(meeting.attendees.join(', '));
    setAgendaItems(allAgenda.map((a) => ({
      id: a.id,
      topic: a.topic,
      duration: a.duration,
      owner: a.owner,
    })));
  }, [meeting, allAgenda]);

  if (!meeting) {
    return (
      <div className="p-10">
        <p className="text-text-secondary">会议不存在</p>
      </div>
    );
  }

  const addAgenda = () => {
    const newId = generateId();
    setAgendaItems([...agendaItems, { id: newId, topic: '', duration: 15, owner: '' }]);
  };

  const updateAgenda = (itemId: string, field: keyof AgendaFormItem, value: string | number) => {
    setAgendaItems(agendaItems.map((item) =>
      item.id === itemId ? { ...item, [field]: value } : item
    ));
  };

  const removeAgenda = (itemId: string) => {
    if (agendaItems.length > 1) {
      setAgendaItems(agendaItems.filter((item) => item.id !== itemId));
      deleteAgendaItem(itemId);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !startTime || !endTime) return;

    const attendeeList = attendees.split(/[,，;；]/).map((s) => s.trim()).filter(Boolean);

    updateMeeting(meeting.id, {
      title,
      description,
      startTime: new Date(startTime).toISOString(),
      endTime: new Date(endTime).toISOString(),
      meetingLink,
      attendees: attendeeList.length > 0 ? attendeeList : ['我'],
    });

    // Update existing agenda items
    agendaItems.forEach((item, index) => {
      if (item.topic.trim()) {
        const existing = allAgenda.find((a) => a.id === item.id);
        if (existing) {
          updateAgendaItem(item.id, {
            topic: item.topic,
            duration: item.duration,
            owner: item.owner || '待定',
            order: index,
          });
        } else {
          addAgendaItem({
            meetingId: meeting.id,
            topic: item.topic,
            duration: item.duration,
            owner: item.owner || '待定',
            order: index,
          });
        }
      }
    });

    showToast('会议已更新', 'success');
    navigate(`/meetings/${meeting.id}`);
  };

  return (
    <div className="p-10 max-w-3xl animate-fade-in">
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-2 text-sm text-text-tertiary hover:text-text-secondary transition-colors mb-6"
      >
        <ArrowLeft size={16} />
        返回
      </button>

      <h1 className="font-display text-2xl font-bold text-text-primary mb-8">编辑会议</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* 基本信息 */}
        <div className="bg-bg-surface rounded-lg border border-white/[0.04] p-6 space-y-5">
          <h2 className="text-sm font-semibold text-text-primary">基本信息</h2>

          <div>
            <label className="block text-xs text-text-tertiary mb-2">会议标题 *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="输入会议标题"
              required
              className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-2.5 text-sm text-text-primary placeholder:text-text-muted focus:outline-none input-glow transition-all duration-200"
            />
          </div>

          <div>
            <label className="block text-xs text-text-tertiary mb-2">会议描述</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="简要描述会议目的"
              rows={3}
              className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-2.5 text-sm text-text-primary placeholder:text-text-muted focus:outline-none input-glow transition-all duration-200 resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-text-tertiary mb-2">开始时间 *</label>
              <input
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                required
                className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-2.5 text-sm text-text-primary focus:outline-none input-glow transition-all duration-200"
              />
            </div>
            <div>
              <label className="block text-xs text-text-tertiary mb-2">结束时间 *</label>
              <input
                type="datetime-local"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                required
                className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-2.5 text-sm text-text-primary focus:outline-none input-glow transition-all duration-200"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs text-text-tertiary mb-2">会议链接</label>
            <input
              type="url"
              value={meetingLink}
              onChange={(e) => setMeetingLink(e.target.value)}
              placeholder="https://meet.example.com/..."
              className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-2.5 text-sm text-text-primary placeholder:text-text-muted focus:outline-none input-glow transition-all duration-200"
            />
          </div>

          <div>
            <label className="block text-xs text-text-tertiary mb-2">参会人（用逗号分隔）</label>
            <input
              type="text"
              value={attendees}
              onChange={(e) => setAttendees(e.target.value)}
              placeholder="张三, 李四, 王五"
              className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-2.5 text-sm text-text-primary placeholder:text-text-muted focus:outline-none input-glow transition-all duration-200"
            />
          </div>
        </div>

        {/* 议程 */}
        <div className="bg-bg-surface rounded-lg border border-white/[0.04] p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-text-primary">会议议程</h2>
            <button
              type="button"
              onClick={addAgenda}
              className="inline-flex items-center gap-1 text-xs text-accent hover:text-accent-hover transition-colors"
            >
              <Plus size={14} />
              添加议题
            </button>
          </div>

          <div className="space-y-3">
            {agendaItems.map((item, index) => (
              <div
                key={item.id}
                className="flex items-center gap-3 bg-bg-base rounded-md border border-white/[0.04] p-3"
              >
                <GripVertical size={16} className="text-text-muted shrink-0" />
                <span className="text-xs text-text-tertiary w-6">{index + 1}</span>
                <input
                  type="text"
                  value={item.topic}
                  onChange={(e) => updateAgenda(item.id, 'topic', e.target.value)}
                  placeholder="议题内容"
                  className="flex-1 bg-transparent text-sm text-text-primary placeholder:text-text-muted focus:outline-none"
                />
                <input
                  type="number"
                  value={item.duration}
                  onChange={(e) => updateAgenda(item.id, 'duration', parseInt(e.target.value) || 0)}
                  placeholder="分钟"
                  min={1}
                  className="w-16 bg-transparent text-sm text-text-primary text-center focus:outline-none"
                />
                <span className="text-xs text-text-tertiary">分钟</span>
                <input
                  type="text"
                  value={item.owner}
                  onChange={(e) => updateAgenda(item.id, 'owner', e.target.value)}
                  placeholder="负责人"
                  className="w-20 bg-transparent text-sm text-text-primary placeholder:text-text-muted focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => removeAgenda(item.id)}
                  className="text-text-muted hover:text-status-danger transition-colors"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* 提交按钮 */}
        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="px-5 py-2.5 border border-white/10 text-text-secondary rounded-sm text-sm font-medium hover:bg-bg-hover transition-all duration-150"
          >
            取消
          </button>
          <button
            type="submit"
            className="px-5 py-2.5 bg-accent text-bg-base rounded-sm text-sm font-semibold hover:brightness-110 transition-all duration-150 btn-scale shadow-glow"
          >
            保存修改
          </button>
        </div>
      </form>
    </div>
  );
}
