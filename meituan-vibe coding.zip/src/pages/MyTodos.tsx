import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  CheckCircle2, Circle, Clock, ArrowRight, Calendar, User, 
  Filter, Search, Flag, Trash2, AlertTriangle, Flame, Target
} from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import EmptyState from '../components/EmptyState';
import { showToast } from '../components/Toast';

interface TodoItem {
  id: string;
  content: string;
  assignee: string;
  status: 'todo' | 'in_progress' | 'done';
  dueDate: string;
  meetingId: string;
  meetingTitle: string;
  priority: 'high' | 'medium' | 'low';
}

const statusConfig = {
  todo: { label: '待处理', icon: Circle, color: 'text-status-warning', bg: 'bg-status-warning/10' },
  in_progress: { label: '进行中', icon: Clock, color: 'text-status-info', bg: 'bg-status-info/10' },
  done: { label: '已完成', icon: CheckCircle2, color: 'text-status-success', bg: 'bg-status-success/10' },
};

const priorityConfig = {
  high: { label: '高', color: 'text-status-danger', bg: 'bg-status-danger/10' },
  medium: { label: '中', color: 'text-status-warning', bg: 'bg-status-warning/10' },
  low: { label: '低', color: 'text-status-info', bg: 'bg-status-info/10' },
};

export default function MyTodos() {
  const navigate = useNavigate();
  const actionItems = useAppStore((s) => s.actionItems);
  const meetings = useAppStore((s) => s.meetings);
  const updateActionItem = useAppStore((s) => s.updateActionItem);
  const deleteActionItem = useAppStore((s) => s.deleteActionItem);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');

  const getPriority = (dueDate: string): 'high' | 'medium' | 'low' => {
    const daysUntil = Math.ceil((new Date(dueDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
    if (daysUntil < 0) return 'high';
    if (daysUntil <= 3) return 'high';
    if (daysUntil <= 7) return 'medium';
    return 'low';
  };

  const todos: TodoItem[] = useMemo(() => {
    return actionItems.map((item) => ({
      ...item,
      meetingTitle: meetings.find((m) => m.id === item.meetingId)?.title || '未知会议',
      priority: getPriority(item.dueDate),
    }));
  }, [actionItems, meetings]);

  const filteredTodos = useMemo(() => {
    return todos.filter((todo) => {
      if (statusFilter !== 'all' && todo.status !== statusFilter) return false;
      if (priorityFilter !== 'all' && todo.priority !== priorityFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          todo.content.toLowerCase().includes(q) ||
          todo.meetingTitle.toLowerCase().includes(q) ||
          todo.assignee.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [todos, statusFilter, priorityFilter, searchQuery]);

  // 有价值的统计
  const now = new Date();
  const weekEnd = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  
  const stats = {
    overdue: todos.filter((t) => t.status !== 'done' && new Date(t.dueDate) < now).length,
    dueThisWeek: todos.filter((t) => t.status !== 'done' && new Date(t.dueDate) >= now && new Date(t.dueDate) <= weekEnd).length,
    highPriority: todos.filter((t) => t.status !== 'done' && getPriority(t.dueDate) === 'high').length,
  };

  const cycleStatus = (id: string, current: string) => {
    const next = current === 'todo' ? 'in_progress' : current === 'in_progress' ? 'done' : 'todo';
    updateActionItem(id, { status: next });
    const labels = { todo: '待处理', in_progress: '进行中', done: '已完成' };
    showToast(`已更新为「${labels[next as keyof typeof labels]}」`, 'success');
  };

  const isOverdue = (dueDate: string, status: string) => {
    return status !== 'done' && new Date(dueDate) < new Date();
  };

  return (
    <div className="p-10 max-w-6xl animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display text-2xl font-bold text-text-primary mb-1">我的待办</h1>
        <p className="text-sm text-text-tertiary">跨会议追踪所有 Action Items</p>
      </div>

      {/* 关键指标 - 只保留有价值的 */}
      <div className="grid grid-cols-3 gap-5 mb-8">
        {[
          { 
            label: '已逾期', 
            value: stats.overdue, 
            icon: AlertTriangle, 
            color: 'text-status-danger', 
            bg: 'bg-status-danger/10',
            desc: '需要立即处理'
          },
          { 
            label: '本周到期', 
            value: stats.dueThisWeek, 
            icon: Target, 
            color: 'text-status-warning', 
            bg: 'bg-status-warning/10',
            desc: '7天内截止'
          },
          { 
            label: '高优先级', 
            value: stats.highPriority, 
            icon: Flame, 
            color: 'text-accent', 
            bg: 'bg-accent/10',
            desc: '3天内截止'
          },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="bg-bg-surface rounded-lg border border-white/[0.04] shadow-md p-5 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-display text-2xl font-bold text-text-primary">{stat.value}</p>
                  <p className="text-sm text-text-tertiary mt-1">{stat.label}</p>
                  <p className="text-xs text-text-muted mt-0.5">{stat.desc}</p>
                </div>
                <div className={`w-10 h-10 rounded-md ${stat.bg} flex items-center justify-center`}>
                  <Icon size={20} className={stat.color} strokeWidth={1.5} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 mb-6">
        <div className="flex items-center gap-2 flex-1 flex-wrap">
          <Filter size={16} className="text-text-tertiary" />
          {(['all', 'todo', 'in_progress', 'done'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-150 ${
                statusFilter === s
                  ? 'bg-accent/15 text-accent'
                  : 'bg-bg-surface text-text-tertiary hover:text-text-secondary border border-white/[0.04]'
              }`}
            >
              {s === 'all' ? '全部' : statusConfig[s].label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <Flag size={14} className="text-text-tertiary" />
          {(['all', 'high', 'medium', 'low'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPriorityFilter(p)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-150 ${
                priorityFilter === p
                  ? priorityConfig[p === 'all' ? 'medium' : p].bg + ' ' + priorityConfig[p === 'all' ? 'medium' : p].color
                  : 'bg-bg-surface text-text-tertiary hover:text-text-secondary border border-white/[0.04]'
              }`}
            >
              {p === 'all' ? '全部' : priorityConfig[p].label}
            </button>
          ))}
        </div>
        <div className="relative min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-tertiary" />
          <input
            type="text"
            placeholder="搜索待办..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-bg-surface border border-white/[0.06] rounded-md pl-9 pr-4 py-2 text-sm text-text-primary placeholder:text-text-tertiary focus:outline-none input-glow transition-all duration-200"
          />
        </div>
      </div>

      {/* Todo List */}
      {filteredTodos.length === 0 ? (
        <div className="bg-bg-surface rounded-lg border border-white/[0.04]">
          <EmptyState type="todos" />
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTodos.map((todo) => {
            const status = statusConfig[todo.status];
            const StatusIcon = status.icon;
            const priority = priorityConfig[todo.priority];
            const overdue = isOverdue(todo.dueDate, todo.status);

            return (
              <div
                key={todo.id}
                className={`flex items-center gap-4 bg-bg-surface rounded-lg border border-white/[0.04] p-4 hover:bg-bg-elevated hover:border-white/[0.08] hover:-translate-y-0.5 hover:shadow-md transition-all duration-200 group ${
                  todo.status === 'done' ? 'opacity-60' : ''
                }`}
              >
                {/* Status Toggle */}
                <button
                  onClick={() => cycleStatus(todo.id, todo.status)}
                  className="shrink-0 transition-all duration-200 hover:scale-110"
                >
                  <StatusIcon size={22} className={status.color} />
                </button>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className={`text-sm font-medium truncate ${
                      todo.status === 'done' ? 'text-text-muted line-through' : 'text-text-primary'
                    }`}>
                      {todo.content}
                    </p>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${priority.bg} ${priority.color}`}>
                      {priority.label}
                    </span>
                    {overdue && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-status-danger/10 text-status-danger">
                        逾期
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-4 text-xs text-text-tertiary">
                    <span className="flex items-center gap-1">
                      <Calendar size={11} />
                      {todo.meetingTitle}
                    </span>
                    <span className="flex items-center gap-1">
                      <User size={11} />
                      {todo.assignee}
                    </span>
                    <span className={`flex items-center gap-1 ${overdue ? 'text-status-danger font-medium' : ''}`}>
                      <Calendar size={11} />
                      截止 {todo.dueDate}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => navigate(`/meetings/${todo.meetingId}`)}
                    className="p-1.5 rounded-md text-text-tertiary hover:text-accent hover:bg-accent/10 transition-all"
                  >
                    <ArrowRight size={14} />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm('确定删除这个待办？')) {
                        deleteActionItem(todo.id);
                        showToast('待办已删除', 'info');
                      }
                    }}
                    className="p-1.5 rounded-md text-text-tertiary hover:text-status-danger hover:bg-status-danger/10 transition-all"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
