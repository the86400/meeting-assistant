import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FileText, Plus, Copy, Trash2, Edit3, Check, X, 
  Sparkles, ChevronRight
} from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import { showToast } from '../components/Toast';
import { generateId } from '../utils/dateUtils';

interface Template {
  id: string;
  name: string;
  description: string;
  structure: string[];
  createdAt: string;
}

const defaultTemplates: Template[] = [
  {
    id: 'default-1',
    name: '标准会议纪要',
    description: '适用于大多数会议的通用纪要模板',
    structure: [
      '## 会议信息',
      '- 时间：{startTime} - {endTime}',
      '- 参会人：{attendees}',
      '',
      '## 议程回顾',
      '{agenda}',
      '',
      '## 讨论要点',
      '{notes}',
      '',
      '## 核心结论',
      '（在此记录会议达成的核心结论和决策）',
      '',
      '## 待办事项',
      '- [ ] （待办 1）',
      '- [ ] （待办 2）',
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'default-2',
    name: '产品评审纪要',
    description: '适用于产品需求评审和设计评审',
    structure: [
      '## 评审信息',
      '- 评审对象：',
      '- 评审时间：{startTime}',
      '- 评审人：{attendees}',
      '',
      '## 需求/方案概述',
      '（简要描述评审的内容）',
      '',
      '## 评审意见',
      '{notes}',
      '',
      '## 修改建议',
      '- [ ] （修改项 1）',
      '- [ ] （修改项 2）',
      '',
      '## 评审结论',
      '- [ ] 通过',
      '- [ ] 有条件通过',
      '- [ ] 不通过，需重新评审',
      '',
      '## 后续行动',
      '- [ ] （行动项 1）',
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'default-3',
    name: '周会纪要',
    description: '适用于团队周会和站会',
    structure: [
      '## 本周进展',
      '（各成员汇报本周完成的工作）',
      '',
      '## 问题与风险',
      '{notes}',
      '',
      '## 下周计划',
      '- [ ] （计划 1）',
      '- [ ] （计划 2）',
      '',
      '## 需要支持',
      '（记录需要团队或外部支持的事项）',
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'default-4',
    name: '头脑风暴纪要',
    description: '适用于创意讨论和头脑风暴会议',
    structure: [
      '## 主题',
      '（本次头脑风暴的主题）',
      '',
      '## 参与者',
      '{attendees}',
      '',
      '## 创意点子',
      '{notes}',
      '',
      '## 可行性评估',
      '| 点子 | 可行性 | 优先级 |',
      '|------|--------|--------|',
      '|      |        |        |',
      '',
      '## 下一步',
      '- [ ] （验证项 1）',
      '- [ ] （验证项 2）',
    ],
    createdAt: new Date().toISOString(),
  },
];

export default function Templates() {
  const navigate = useNavigate();
  const meetings = useAppStore((s) => s.meetings);
  const updateMeeting = useAppStore((s) => s.updateMeeting);

  const [templates, setTemplates] = useState<Template[]>(defaultTemplates);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newStructure, setNewStructure] = useState('## 会议信息\n\n## 讨论要点\n\n## 核心结论\n\n## 待办事项\n- [ ] ');

  const handleCopy = (template: Template) => {
    navigator.clipboard.writeText(template.structure.join('\n'));
    showToast('模板内容已复制', 'success');
  };

  const handleDelete = (id: string) => {
    if (confirm('确定删除这个模板？')) {
      setTemplates(templates.filter((t) => t.id !== id));
      showToast('模板已删除', 'info');
    }
  };

  const handleEdit = (template: Template) => {
    setEditingId(template.id);
    setEditName(template.name);
    setEditDesc(template.description);
  };

  const handleSaveEdit = (id: string) => {
    setTemplates(templates.map((t) => 
      t.id === id ? { ...t, name: editName, description: editDesc } : t
    ));
    setEditingId(null);
    showToast('模板已更新', 'success');
  };

  const handleCreate = () => {
    if (!newName.trim()) return;
    const newTemplate: Template = {
      id: generateId(),
      name: newName,
      description: newDesc,
      structure: newStructure.split('\n'),
      createdAt: new Date().toISOString(),
    };
    setTemplates([...templates, newTemplate]);
    setShowCreate(false);
    setNewName('');
    setNewDesc('');
    setNewStructure('## 会议信息\n\n## 讨论要点\n\n## 核心结论\n\n## 待办事项\n- [ ] ');
    showToast('模板已创建', 'success');
  };

  const handleApplyToMeeting = (template: Template, meetingId: string) => {
    const meeting = meetings.find((m) => m.id === meetingId);
    if (!meeting) return;

    let content = template.structure.join('\n');
    content = content.replace('{startTime}', meeting.startTime.slice(0, 16).replace('T', ' '));
    content = content.replace('{endTime}', meeting.endTime.slice(0, 16).replace('T', ' '));
    content = content.replace('{attendees}', meeting.attendees.join('、'));
    
    const agendaItems = useAppStore.getState().agendaItems
      .filter((a) => a.meetingId === meetingId)
      .sort((a, b) => a.order - b.order);
    const agendaStr = agendaItems.map((a, i) => `${i + 1}. ${a.topic} (${a.duration}分钟)`).join('\n');
    content = content.replace('{agenda}', agendaStr || '（无议程）');

    const notes = useAppStore.getState().notes
      .filter((n) => n.meetingId === meetingId);
    const notesStr = notes.map((n) => `- ${n.content}`).join('\n');
    content = content.replace('{notes}', notesStr || '（无速记内容）');

    updateMeeting(meetingId, { summary: content, status: 'pending_confirm' });
    showToast('模板已应用到会议', 'success');
    navigate(`/meetings/${meetingId}`);
  };

  return (
    <div className="p-10 max-w-6xl animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary mb-1">纪要模板</h1>
          <p className="text-sm text-text-tertiary">管理和使用会议纪要模板</p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent text-bg-base rounded-sm text-sm font-semibold hover:brightness-110 transition-all duration-150 btn-scale shadow-glow"
        >
          <Plus size={16} />
          新建模板
        </button>
      </div>

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-text-primary/20 backdrop-blur-sm" onClick={() => setShowCreate(false)} />
          <div className="relative bg-bg-surface rounded-lg border border-white/[0.04] p-8 w-full max-w-2xl max-h-[80vh] overflow-y-auto animate-slide-up shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-text-primary">新建模板</h2>
              <button onClick={() => setShowCreate(false)} className="text-text-tertiary hover:text-text-secondary">
                <X size={20} />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-text-tertiary mb-2">模板名称 *</label>
                <input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="输入模板名称"
                  className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-2.5 text-sm text-text-primary placeholder:text-text-tertiary focus:outline-none input-glow transition-all duration-200"
                />
              </div>
              <div>
                <label className="block text-xs text-text-tertiary mb-2">描述</label>
                <input
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="简要描述模板用途"
                  className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-2.5 text-sm text-text-primary placeholder:text-text-tertiary focus:outline-none input-glow transition-all duration-200"
                />
              </div>
              <div>
                <label className="block text-xs text-text-tertiary mb-2">模板结构</label>
                <textarea
                  value={newStructure}
                  onChange={(e) => setNewStructure(e.target.value)}
                  rows={12}
                  className="w-full bg-bg-base border border-white/[0.06] rounded-md px-4 py-3 text-sm text-text-primary font-mono leading-relaxed focus:outline-none input-glow resize-none transition-all duration-200"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => setShowCreate(false)}
                className="px-5 py-2.5 text-text-secondary hover:bg-bg-hover rounded-sm text-sm transition-all"
              >
                取消
              </button>
              <button
                onClick={handleCreate}
                className="px-5 py-2.5 bg-accent text-bg-base rounded-sm text-sm font-semibold hover:brightness-110 transition-all btn-scale"
              >
                创建模板
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Templates Grid */}
      <div className="grid grid-cols-2 gap-5">
        {templates.map((template) => {
          const isSelected = selectedTemplate === template.id;
          const isEditing = editingId === template.id;

          return (
            <div
              key={template.id}
              className={`bg-bg-surface rounded-lg border border-white/[0.04] shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 overflow-hidden ${
                isSelected ? 'ring-2 ring-accent/30' : ''
              }`}
            >
              <div className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-md bg-accent/10 flex items-center justify-center">
                      <FileText size={20} className="text-accent" />
                    </div>
                    <div>
                      {isEditing ? (
                        <input
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="text-sm font-semibold text-text-primary bg-transparent border-b border-accent focus:outline-none"
                        />
                      ) : (
                        <h3 className="text-sm font-semibold text-text-primary">{template.name}</h3>
                      )}
                      {isEditing ? (
                        <input
                          value={editDesc}
                          onChange={(e) => setEditDesc(e.target.value)}
                          className="text-xs text-text-secondary bg-transparent border-b border-accent/50 focus:outline-none mt-1"
                        />
                      ) : (
                        <p className="text-xs text-text-tertiary mt-0.5">{template.description}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-1">
                    {isEditing ? (
                      <>
                        <button
                          onClick={() => handleSaveEdit(template.id)}
                          className="p-1.5 rounded-md text-status-success hover:bg-status-success/10 transition-all"
                        >
                          <Check size={14} />
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="p-1.5 rounded-md text-text-tertiary hover:bg-bg-hover transition-all"
                        >
                          <X size={14} />
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => handleCopy(template)}
                          className="p-1.5 rounded-md text-text-tertiary hover:text-accent hover:bg-accent/10 transition-all"
                          title="复制模板"
                        >
                          <Copy size={14} />
                        </button>
                        <button
                          onClick={() => handleEdit(template)}
                          className="p-1.5 rounded-md text-text-tertiary hover:text-accent hover:bg-accent/10 transition-all"
                          title="编辑"
                        >
                          <Edit3 size={14} />
                        </button>
                        {!template.id.startsWith('default') && (
                          <button
                            onClick={() => handleDelete(template.id)}
                            className="p-1.5 rounded-md text-text-tertiary hover:text-status-danger hover:bg-status-danger/10 transition-all"
                            title="删除"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </>
                    )}
                  </div>
                </div>

                {/* Structure Preview */}
                <div 
                  className="bg-bg-elevated rounded-md p-3 cursor-pointer hover:bg-bg-hover transition-colors"
                  onClick={() => setSelectedTemplate(isSelected ? null : template.id)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-text-tertiary">模板结构预览</span>
                    <ChevronRight 
                      size={14} 
                      className={`text-text-muted transition-transform duration-200 ${isSelected ? 'rotate-90' : ''}`}
                    />
                  </div>
                  {isSelected && (
                    <div className="space-y-1 mt-2 animate-fade-in">
                      {template.structure.slice(0, 8).map((line, i) => (
                        <p key={i} className="text-xs text-text-secondary font-mono truncate">
                          {line || '\u00A0'}
                        </p>
                      ))}
                      {template.structure.length > 8 && (
                        <p className="text-xs text-text-muted">... 还有 {template.structure.length - 8} 行</p>
                      )}
                    </div>
                  )}
                  {!isSelected && (
                    <p className="text-xs text-text-muted truncate">
                      {template.structure[0]} ...
                    </p>
                  )}
                </div>

                {/* Apply to Meeting */}
                {isSelected && meetings.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-white/[0.06] animate-fade-in">
                    <p className="text-xs text-text-tertiary mb-2">应用到会议</p>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {meetings
                        .filter((m) => m.status === 'pending_summary' || m.status === 'upcoming')
                        .map((meeting) => (
                          <button
                            key={meeting.id}
                            onClick={() => handleApplyToMeeting(template, meeting.id)}
                            className="w-full flex items-center gap-3 p-2.5 rounded-md hover:bg-bg-hover transition-all text-left group"
                          >
                            <Sparkles size={14} className="text-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-text-primary truncate">{meeting.title}</p>
                              <p className="text-[10px] text-text-muted">
                                {new Date(meeting.startTime).toLocaleDateString('zh-CN')}
                              </p>
                            </div>
                            <ChevronRight size={12} className="text-text-muted" />
                          </button>
                        ))}
                      {meetings.filter((m) => m.status === 'pending_summary' || m.status === 'upcoming').length === 0 && (
                        <p className="text-xs text-text-muted text-center py-2">暂无可用会议</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Usage Tips */}
      <div className="mt-8 bg-bg-surface rounded-lg border border-white/[0.04] p-6 shadow-md">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-md bg-accent/10 flex items-center justify-center">
            <Sparkles size={16} className="text-accent" />
          </div>
          <h3 className="text-sm font-semibold text-text-primary">使用提示</h3>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-md bg-status-info/10 flex items-center justify-center shrink-0 mt-0.5">
              <span className="text-xs text-status-info font-bold">1</span>
            </div>
            <div>
              <p className="text-xs font-medium text-text-primary">选择模板</p>
              <p className="text-xs text-text-tertiary mt-0.5">点击模板查看结构预览</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-md bg-status-info/10 flex items-center justify-center shrink-0 mt-0.5">
              <span className="text-xs text-status-info font-bold">2</span>
            </div>
            <div>
              <p className="text-xs font-medium text-text-primary">应用到会议</p>
              <p className="text-xs text-text-tertiary mt-0.5">展开后选择目标会议</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-md bg-status-info/10 flex items-center justify-center shrink-0 mt-0.5">
              <span className="text-xs text-status-info font-bold">3</span>
            </div>
            <div>
              <p className="text-xs font-medium text-text-primary">编辑确认</p>
              <p className="text-xs text-text-tertiary mt-0.5">在会议详情中编辑并发布</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
