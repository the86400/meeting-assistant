import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Plus, Filter, MoreHorizontal, Edit2, Trash2, XCircle, FileText } from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import StatusBadge from '../components/StatusBadge';
import EmptyState from '../components/EmptyState';
import { showToast } from '../components/Toast';
import { formatDateTime } from '../utils/dateUtils';
import type { MeetingStatus } from '../types';

const filters: { label: string; value: MeetingStatus | 'all' }[] = [
  { label: '全部', value: 'all' },
  { label: '待开始', value: 'upcoming' },
  { label: '进行中', value: 'ongoing' },
  { label: '待跟进', value: 'pending_summary' },
  { label: '待确认', value: 'pending_confirm' },
  { label: '已完成', value: 'completed' },
  { label: '已取消', value: 'cancelled' },
];

export default function MeetingList() {
  const navigate = useNavigate();
  const meetings = useAppStore((s) => s.meetings);
  const updateMeeting = useAppStore((s) => s.updateMeeting);
  const deleteMeeting = useAppStore((s) => s.deleteMeeting);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<MeetingStatus | 'all'>('all');
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  const filteredMeetings = meetings
    .filter((m) => {
      if (activeFilter !== 'all' && m.status !== activeFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          m.title.toLowerCase().includes(q) ||
          m.description.toLowerCase().includes(q) ||
          m.attendees.some((a) => a.toLowerCase().includes(q))
        );
      }
      return true;
    })
    .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());

  return (
    <div className="p-10 max-w-6xl animate-fade-in">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">会议列表</h1>
          <p className="text-sm text-text-tertiary mt-1">管理全部会议</p>
        </div>
        <button
          onClick={() => navigate('/meetings/new')}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent text-bg-base rounded-sm text-sm font-semibold hover:brightness-110 transition-all duration-150 btn-scale shadow-glow"
        >
          <Plus size={16} />
          创建会议
        </button>
      </div>

      {/* 筛选和搜索 */}
      <div className="flex items-center gap-4 mb-6">
        <div className="flex items-center gap-2 flex-1 flex-wrap">
          <Filter size={16} className="text-text-tertiary" />
          {filters.map((f) => (
            <button
              key={f.value}
              onClick={() => setActiveFilter(f.value)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-150 ${
                activeFilter === f.value
                  ? 'bg-accent/15 text-accent'
                  : 'bg-bg-surface text-text-tertiary hover:text-text-secondary border border-white/[0.04]'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="relative min-w-[240px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-tertiary" />
          <input
            type="text"
            placeholder="搜索会议..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-bg-surface border border-white/[0.06] rounded-md pl-9 pr-4 py-2 text-sm text-text-primary placeholder:text-text-tertiary focus:outline-none input-glow transition-all duration-200"
          />
        </div>
      </div>

      {/* 会议列表 */}
      {filteredMeetings.length === 0 ? (
        <div className="bg-bg-surface rounded-lg border border-white/[0.04]">
          <EmptyState
            type={searchQuery ? 'search' : 'meetings'}
            onAction={searchQuery ? () => setSearchQuery('') : () => navigate('/meetings/new')}
          />
        </div>
      ) : (
        <div className="space-y-3">
          {filteredMeetings.map((meeting, index) => (
            <div
              key={meeting.id}
              className="flex items-center gap-4 bg-bg-surface rounded-lg border border-white/[0.04] p-4 hover:bg-bg-elevated hover:border-white/[0.08] hover:-translate-y-0.5 hover:shadow-lg transition-all duration-200 group"
              style={{ animationDelay: `${index * 40}ms` }}
            >
              <div
                onClick={() => navigate(`/meetings/${meeting.id}`)}
                className="flex items-center gap-4 flex-1 cursor-pointer min-w-0"
              >
                <div className="flex flex-col items-center min-w-[100px]">
                  <span className="text-xs text-text-tertiary">
                    {formatDateTime(meeting.startTime)}
                  </span>
                </div>
                <div className="w-px h-10 bg-white/[0.06]" />
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-semibold text-text-primary truncate group-hover:text-accent transition-colors">{meeting.title}</h3>
                  <p className="text-xs text-text-tertiary mt-0.5 truncate">{meeting.description}</p>
                </div>
                <StatusBadge status={meeting.status} />
                <div className="flex -space-x-2">
                  {meeting.attendees.slice(0, 3).map((name, i) => (
                    <div
                      key={i}
                      className="w-7 h-7 rounded-full bg-bg-elevated border border-bg-surface flex items-center justify-center text-xs text-text-secondary"
                    >
                      {name[0]}
                    </div>
                  ))}
                  {meeting.attendees.length > 3 && (
                    <div className="w-7 h-7 rounded-full bg-bg-elevated border border-bg-surface flex items-center justify-center text-xs text-text-tertiary">
                      +{meeting.attendees.length - 3}
                    </div>
                  )}
                </div>
              </div>

              {/* 操作菜单 */}
              <div className="relative">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setOpenMenuId(openMenuId === meeting.id ? null : meeting.id);
                  }}
                  className="p-1.5 rounded-md text-text-tertiary hover:text-text-secondary hover:bg-bg-hover transition-all opacity-0 group-hover:opacity-100"
                >
                  <MoreHorizontal size={16} />
                </button>
                {openMenuId === meeting.id && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setOpenMenuId(null)}
                    />
                    <div className="absolute right-0 top-full mt-1 w-40 bg-bg-elevated rounded-lg border border-white/[0.06] shadow-lg z-50 py-1 animate-fade-in">
                      {meeting.status !== 'cancelled' && meeting.status !== 'completed' && (
                        <>
                          <button
                            onClick={() => {
                              navigate(`/meetings/${meeting.id}/edit`);
                              setOpenMenuId(null);
                            }}
                            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-text-secondary hover:bg-bg-hover transition-colors"
                          >
                            <Edit2 size={14} />
                            编辑
                          </button>
                          <button
                            onClick={() => {
                              navigate(`/meetings/${meeting.id}`);
                              setOpenMenuId(null);
                            }}
                            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-text-secondary hover:bg-bg-hover transition-colors"
                          >
                            <FileText size={14} />
                            查看详情
                          </button>
                          <button
                            onClick={() => {
                              if (confirm('确定要取消这个会议吗？')) {
                                updateMeeting(meeting.id, { status: 'cancelled' });
                                showToast('会议已取消', 'info');
                              }
                              setOpenMenuId(null);
                            }}
                            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-text-secondary hover:bg-bg-hover transition-colors"
                          >
                            <XCircle size={14} />
                            取消会议
                          </button>
                          <div className="mx-3 my-1 h-px bg-white/[0.06]" />
                        </>
                      )}
                      <button
                        onClick={() => {
                          if (confirm('确定要删除这个会议吗？')) {
                            deleteMeeting(meeting.id);
                            showToast('会议已删除', 'info');
                          }
                          setOpenMenuId(null);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-status-danger hover:bg-status-danger/10 transition-colors"
                      >
                        <Trash2 size={14} />
                        删除
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
