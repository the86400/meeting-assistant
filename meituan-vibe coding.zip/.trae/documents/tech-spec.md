# 视频会议助手 — 技术架构文档

## 1. 架构设计

```mermaid
graph TB
    subgraph 前端层
        A[React 18 + TypeScript]
        B[React Router DOM]
        C[Tailwind CSS]
        D[Zustand 状态管理]
        E[Lucide React 图标]
    end

    subgraph 数据层
        F[LocalStorage 持久化]
        G[Zustand Store]
    end

    A --> B
    A --> C
    A --> D
    A --> E
    D --> G
    G --> F
```

---

## 2. 技术选型

- **前端框架**：React@18 + TypeScript
- **构建工具**：Vite
- **路由**：React Router DOM@6
- **状态管理**：Zustand
- **样式方案**：Tailwind CSS@3
- **图标库**：Lucide React
- **数据持久化**：LocalStorage（JSON序列化）
- **初始化工具**：vite-init（react-ts 模板）

---

## 3. 路由定义

| 路由 | 用途 |
|------|------|
| `/` | 会议概览页 (Dashboard) |
| `/meetings` | 会议列表页 |
| `/meetings/new` | 创建会议页 |
| `/meetings/:id` | 会议详情页 |
| `/todos` | 我的待办页 |

---

## 4. 数据模型

### 4.1 实体关系图

```mermaid
erDiagram
    MEETING ||--o{ AGENDA_ITEM : contains
    MEETING ||--o{ NOTE : has
    MEETING ||--o{ ACTION_ITEM : generates
    MEETING {
        string id PK
        string title
        string description
        datetime startTime
        datetime endTime
        string meetingLink
        array attendees
        string status
        string summary
        datetime createdAt
        datetime updatedAt
    }
    AGENDA_ITEM {
        string id PK
        string meetingId FK
        string topic
        int duration
        string owner
        int order
    }
    NOTE {
        string id PK
        string meetingId FK
        string content
        string tag
        datetime createdAt
    }
    ACTION_ITEM {
        string id PK
        string meetingId FK
        string content
        string assignee
        string status
        datetime dueDate
        datetime createdAt
    }
```

### 4.2 TypeScript 类型定义

```typescript
// 会议状态
type MeetingStatus = 'upcoming' | 'ongoing' | 'pending_summary' | 'pending_confirm' | 'completed';

// 会议
interface Meeting {
  id: string;
  title: string;
  description: string;
  startTime: string; // ISO 8601
  endTime: string;   // ISO 8601
  meetingLink: string;
  attendees: string[];
  status: MeetingStatus;
  summary: string;
  createdAt: string;
  updatedAt: string;
}

// 议程项
interface AgendaItem {
  id: string;
  meetingId: string;
  topic: string;
  duration: number; // 分钟
  owner: string;
  order: number;
}

// 速记
interface Note {
  id: string;
  meetingId: string;
  content: string;
  tag: 'decision' | 'todo' | 'question' | 'general';
  createdAt: string;
}

// 待办事项
interface ActionItem {
  id: string;
  meetingId: string;
  content: string;
  assignee: string;
  status: 'todo' | 'in_progress' | 'done';
  dueDate: string;
  createdAt: string;
}

// 应用状态
interface AppState {
  meetings: Meeting[];
  agendaItems: AgendaItem[];
  notes: Note[];
  actionItems: ActionItem[];
}
```

---

## 5. 项目结构

```
├── public/
│   └── (静态资源)
├── src/
│   ├── components/          # 可复用组件
│   │   ├── Sidebar.tsx
│   │   ├── MeetingCard.tsx
│   │   ├── AgendaEditor.tsx
│   │   ├── NoteTaker.tsx
│   │   ├── SummaryViewer.tsx
│   │   ├── TodoBoard.tsx
│   │   └── StatusBadge.tsx
│   ├── pages/               # 页面组件
│   │   ├── Dashboard.tsx
│   │   ├── MeetingList.tsx
│   │   ├── MeetingDetail.tsx
│   │   ├── CreateMeeting.tsx
│   │   └── MyTodos.tsx
│   ├── hooks/               # 自定义 Hooks
│   │   ├── useMeetings.ts
│   │   ├── useAgenda.ts
│   │   ├── useNotes.ts
│   │   └── useTodos.ts
│   ├── store/               # Zustand 状态管理
│   │   └── useAppStore.ts
│   ├── types/               # TypeScript 类型
│   │   └── index.ts
│   ├── utils/               # 工具函数
│   │   ├── storage.ts
│   │   ├── dateUtils.ts
│   │   └── mockData.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── .trae/documents/         # 产品文档
│   ├── prd.md
│   └── tech-spec.md
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.js
└── postcss.config.js
```

---

## 6. 状态管理设计

### Zustand Store 结构

```typescript
interface AppStore {
  // 数据
  meetings: Meeting[];
  agendaItems: AgendaItem[];
  notes: Note[];
  actionItems: ActionItem[];

  // 会议操作
  addMeeting: (meeting: Omit<Meeting, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateMeeting: (id: string, data: Partial<Meeting>) => void;
  deleteMeeting: (id: string) => void;

  // 议程操作
  addAgendaItem: (item: Omit<AgendaItem, 'id'>) => void;
  updateAgendaItem: (id: string, data: Partial<AgendaItem>) => void;
  deleteAgendaItem: (id: string) => void;
  reorderAgendaItems: (meetingId: string, newOrder: string[]) => void;

  // 速记操作
  addNote: (note: Omit<Note, 'id' | 'createdAt'>) => void;
  deleteNote: (id: string) => void;

  // 待办操作
  addActionItem: (item: Omit<ActionItem, 'id' | 'createdAt'>) => void;
  updateActionItem: (id: string, data: Partial<ActionItem>) => void;
  deleteActionItem: (id: string) => void;

  // AI 纪要生成（模拟）
  generateSummary: (meetingId: string) => string;
}
```

### 持久化方案

- 使用 Zustand 的 `persist` 中间件
- 存储介质：LocalStorage
- 键名：`meeting-assistant-data`
- 自动同步：状态变更自动写入 LocalStorage

---

## 7. 关键实现要点

### 7.1 AI 纪要生成（模拟）

基于议程 + 速记内容，按模板生成结构化纪要：

```
# 会议纪要：{会议标题}

## 会议信息
- 时间：{开始时间} - {结束时间}
- 参会人：{参会人列表}

## 议程回顾
{议程列表}

## 讨论要点
{速记内容整理}

## 核心结论
{提取关键决策}

## 待办事项
{提取 Action Items}
```

### 7.2 会议状态自动流转

- 当前时间 < 开始时间：`upcoming`（待开始）
- 开始时间 <= 当前时间 <= 结束时间：`ongoing`（进行中）
- 当前时间 > 结束时间 且 无纪要：`pending_summary`（待生成纪要）
- 纪要已生成但未确认：`pending_confirm`（待确认）
- 纪要已确认发布：`completed`（已完成）

### 7.3 初始化数据

应用首次启动时，注入 3-5 条示例会议数据，帮助用户理解功能。

---

## 8. 依赖清单

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.20.0",
    "zustand": "^4.4.0",
    "lucide-react": "^0.294.0"
  },
  "devDependencies": {
    "typescript": "^5.2.0",
    "vite": "^5.0.0",
    "tailwindcss": "^3.3.0",
    "postcss": "^8.4.0",
    "autoprefixer": "^10.4.0",
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0"
  }
}
```
